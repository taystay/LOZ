﻿using Microsoft.Xna.Framework;

namespace LOZ.ControllerClasses
{
    public interface IController
    {
        public void Update(GameTime gametime);
    }
}
