﻿namespace LOZ.CommandClasses
{
    public interface ICommand
    {
        public void execute();
    }
}
