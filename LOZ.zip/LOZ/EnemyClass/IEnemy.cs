﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using LOZ.Collision;

namespace LOZ.EnemyClass
{
    public interface IEnemy : IGameObjects
    {
        //Nothing here just a separation between enemies and the rest of the game Object
    }
}
